import paketDrugaKlasa.DrugaKlasa;

public class HelloWorld{
public static void main (String[]args){
System.out.println("Hello World");
DrugaKlasa drugaKlasa;
System.out.println("Got drugaKlasa");
}
}