package paketDrugaKlasa;

public class DrugaKlasa{
public static void main (String[]args){
}
}